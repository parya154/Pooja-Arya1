angular.module("mymod").config(function($routeProvider){
			$routeProvider.when("/",{
				controller:"controller",
				templateUrl:"table.html"
			})
		});