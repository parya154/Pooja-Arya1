var mymod = (function(){
    return {
        message : "Welcome to your life"
    }
}())
