var fs=require("fs");

fs.readFile("./data.txt",function(erroe,data){
	console.log(data.toString());
});
/*
var data=JSON.parse(fs.readFileSync("./data.json").toString());
console.log(data[0].title);
*/