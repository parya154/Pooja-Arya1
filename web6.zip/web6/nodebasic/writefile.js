var fs=require("fs");
/*
fs.writeFile("./some.txt","welcome to your life",function(error,data){
	console.log("line #4");
})
console.log("line #6");

*/
console.log("line #9");
fs.writeFileSync("./some.txt","welcome to your life");
console.log("line #11");
