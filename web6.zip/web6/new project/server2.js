var express=require("express")
var bp=require("body-parser");
var app=express();
app.use(bp.json());
var  data=[];
data=[
{
	"fname":"pooja",
	"lname":"arya"
}
]

