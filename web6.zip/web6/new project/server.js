var express=require("express");
var bp=require("body-parser")
var mongo=require("mongojs");
var app=express();
app.use(bp.json())
var db=mongo("pooja",['emp1']);
var data=[{
	"fname":"pooja",
	"lname":"arya"
}]




app.get("/",function(req,res){
	res.send();
})


app.get("/hero",function(req,res){
	db.emp1.find(function(error,data){
		console.log(data);
		res.send(data);
	})
})

app.get("/hero/ins",function(req,res){
	db.emp1.insert(data,function(error,docs){
		console.log(docs);
		res.json(docs);
	})
})

app.listen(1111);
console.log("port 1111")
