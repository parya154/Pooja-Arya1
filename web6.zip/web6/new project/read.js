var fs=require("fs");
fs.readFile("data.json",function(error,data){
	console.log(data.toString());
})

var fs=require("fs");
var data=JSON.parse(fs.readFileSync("data.json").toString());
console.log(data[0].fname)
