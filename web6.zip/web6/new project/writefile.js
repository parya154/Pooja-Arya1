var fs=require("fs");
fs.writeFile("some.txt","hello");


