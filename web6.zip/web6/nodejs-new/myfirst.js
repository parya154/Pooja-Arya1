//var hero={
//	fname:"bruce",
//	lname:"wayne"
//}
//console.log(hero.fname);
 
 var fun=require("./myfirst");
 console.log(fun());
