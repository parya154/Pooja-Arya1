var gulp=require("gulp");
var gulputil=require("gulp-util");

gulp.task("mindtree",function(){
	gulputil.log("first task")
})
