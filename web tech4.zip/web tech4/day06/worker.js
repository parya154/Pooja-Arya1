for(var i = 0; i < 10000000; i++){
                //document.getElementsByTagName("h1")[0].innerHTML = i;
                postMessage(i);
              };
