var express=require("express");
var app=express();
var bp=require("body-parser")
//app.set("view engine","ejs")
app.use(express.static(__dirname));
//app.use(express.static(__dirname+"/script"));
//app.use(express.static(__dirname+"/views"));
var title="my applicaton";
var message="welcome to possible";
var heroes=["batman","superman","spiderman","ironman","rajani"]
app.use(bp.urlencoded());
app.use(express.static(__dirname+"/lib"));
app.use(express.static(__dirname+"/script"));
app.get("/",function(req,res){
	res.render("home1.jade",{
		msg:message,
		t:title,
		hlist:heroes
	})
});
app.post("/",function(req,res){
	console.log("post request");
	console.log(req.body.heroName);
	heroes.push(req.body.heroName)
	res.render("home1.jade",{
		msg:message,
		t:title,
		hlist:heroes
	})
});
	

app.listen(1111);
console.log("localhost:1111");
