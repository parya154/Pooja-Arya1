$(function(){
 $("body").css("border","solid red 5px");
 $("ul").css("border","solid blue 5px");
});