
var express=require("express");
var app=express();
var bp=require("body-parser");
app.use=bp.json;
    app.use(express.static(__dirname));
var data=[];
data=[
{
"title":"batman",
"fname":"bruce",
"lname":"wayne",
"city":"gothem"
},
{

"title":"superman",
"fname":"clark",
"lname":"kent",
"city":"metropolins"
}
];


   app.get("/",function(req,res){
	res.send("ghg");
});
app.get("/herolist",function(req,res){
	res.json(data);
});

app.listen(1122);
console.log("server is running on localhost:1122"); 
