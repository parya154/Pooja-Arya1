var express=require("express");
var app=express();
app.get("/",function(req,res){
	res.send();
});
app.get("herolist",function(req,res){
	res.send()
})
app.listen(5555);
console.log("server is running on local host 5555");
/*
var express=function(){
	return {
		get:function(path,listener){
			
		}
	}
}
*/ var fs=require("fs");
var data=JSON.parse(fs.readFile("./data.json").toStrin)
