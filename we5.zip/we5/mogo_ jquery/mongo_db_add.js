

 var express=require("express");
var app=express();
var bp=require("body-parser");
var mongo=require("mongojs");
var db=mongo("campusminds",['herolist']);  
app.use(bp.json());
app.use(express.static(__dirname));
var data={};
app.get("/",function(req,res){
 //res.send(data);
 res.send("Hello");
});
app.get("/herolist",function(req,res){
 db.campusminds.find(function(error,documents){
 console.log(documents);
 res.json(documents);
 });
});
app.post("/herolist",function(req,res){
 console.log(req.body);
 db.camousminds.insert(req.body,function(error,docs){
  console.log(docs);
  res.json(docs);
 });
});
//var prt1=app.listen();  // for dynamic port number,its kepp changing every time
//app.send("Hello there");

app.listen(5555);
//console.log("server is running on local host:"+krish.address().port);
console.log("server is running on local host: 5555");