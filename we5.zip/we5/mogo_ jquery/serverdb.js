var express=require("express");
var bp=require("body-parser");
var mongo=require("mongojs");
var db=mongo("campusminds",["herolist"]);
var app=express();
	app.use(bp.json());
    app.use(express.static(__dirname));

   app.get("/",function(req,res){
	res.send("asdf");
});
app.get("/herolist",function(req,res){
	db.herolist.find(function(error,documents){
	console.log(documents);
	res.json(documents);
});
});

app.listen(1122);
console.log("server is running on localhost:1122"); 
