(function(){
angular.module("module")
	.controller("controller",function($scope){
		$scope.heroes = [
{title:'Batman',     fname : 'Bruce',  lname : 'Wayne',     city : 'Gotham',        power : 7,   price : 876.45678,   releasedate : '2016-03-30',   photo: 'images/batman.jpg'},
{title:'Superman',   fname : 'Clark',  lname : 'Kent',      city : 'Metropolis',    power : 8,   price : 940.64578,   releasedate : '2016-02-15',   photo: 'images/superman.jpg'},
{title:'Spiderman',  fname : 'Peter',  lname : 'Parker',    city : 'New york',      power : 7,   price : 750.46758,   releasedate : '2016-01-26',   photo: 'images/spiderman.jpg'},
{title:'Ironman',    fname : 'Tony',   lname : 'Stark',     city : 'New york',      power : 7,   price : 450.54678,   releasedate : '2016-08-18',   photo: 'images/ironman.jpg'},
{title:'Phantom',    fname : 'Kit',    lname : 'Walker',    city : 'Bhangala',      power : 6,   price : 320.74568,   releasedate : '2016-06-24',   photo: 'images/phantom.jpg'}
];
 $scope.sorton='title'; 
 $scope.rev=false;
 $scope.sortfun=function(val){
 	$scope.sorton=val;
 $scope.rev=!$scope.rev
 }
 })
 }());
 