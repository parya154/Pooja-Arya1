(function(){
	

angular.module("module",[]);
}());