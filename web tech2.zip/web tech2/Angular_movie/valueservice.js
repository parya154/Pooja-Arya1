(function(){
angular.module("app").value("message","welcome");
}())
