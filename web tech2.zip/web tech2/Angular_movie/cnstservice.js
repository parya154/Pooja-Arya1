(function(){
angular.module("app").constant("msg","hello");
}())
