	angular.module("app").config(function($routeProvider){
		
		$routeProvider.when("/",{
			controller:"controller1",
			templateUrl:"table.html"
		
		})
		.when("/moviesacted/:id",{
			controller:"moviecontroller",
			templateUrl:"movielist.html"
		});
		});