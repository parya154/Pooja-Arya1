define(function(){
		angular.module("app1",[]).controller("mycontroller",function($scope){
		$scope.title="batman"
	})
});