//define(name,[dependencies],function)

define(function(){
	angular.module("app",["app1"]);
})

	