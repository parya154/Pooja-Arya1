require.config({
	paths:{
		"ng":"../lib/angular",
		"app"    : "app",
		"am"     :  "app1",
	},
	shim:{
		"app" :{
			
		deps : ["ng","am"]
	},
	"am" :{
		deps : ["ng"]
	}
  }
	
});
 require(["app"],function(){
 	angular.bootstrap(document.body,["app"]);
 });
