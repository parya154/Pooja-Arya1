var express=require("express");
var bp=require("body-parser");
var mongo=require("mongojs");
//var db=mongo("mtlist",["emp"]);
var db=mongo("user:pass@ds015780.mlab.com:15780/campusmind",["emp"])
var app=express();
	app.use(bp.json());
    app.use(express.static(__dirname));

app.listen(1122);
   app.get("/",function(req,res){
	res.send("asdf");
});

//read
app.get("/employees",function(req,res){
	db.emp.find(function(error,documents){
	console.log(documents);
	res.send(documents);
});
});


//create
app.post("/employees",function(req,res){
	db.emp.insert(req.body,function(error,docs){
		console.log(docs)
		res.json(docs);
	});
});

//delete
app.delete("/employees/:id",function(req,res){
	var eid=req.params.id;
	console.log("delete req");
	db.emp.remove({_id:mongo.ObjectId(eid)},function(err,doc){
		res.json(doc);
	});
});

//update
app.put("/employees/:id",function(req,res){
	var eid=req.params.id;
	db.emp.findAndModify({
		query:{_id:mongo.ObjectId(eid)},
		update:{$set:{
			fname:req.body.fname,
			lname:req.body.lname,
			city:req.body.city,
			mid:req.body.mid,
			email:req.body.email,
		} },
		new:true},function(error,doc){
			res.send(doc);
		}
		);
});

//edit

app.get("/employees/:id",function(req,res){
	console.log("dedit req sent");
	var eid=req.params.id;
	
	db.emp.findOne({_id:mongo.ObjectId(eid)},function(err,doc){
		console.log(doc)
		res.json(doc);
	});
});

console.log("server is running on localhost:1122"); 
//mongo.ObjectId is a method to convert i/p number into object id.=db.emp.remove(_id:mongo.toString())
