angular.module("mymod")
	.controller("mycontroller1",function($scope){
		$scope.message="hello world";
	});