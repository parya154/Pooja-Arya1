angular.module("mymod")
	.controller("mycontroller2",function($scope){
		$scope.message="welcome to possible";
	});