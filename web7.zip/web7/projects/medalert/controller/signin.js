angular.module("medalert").controller("signin",function($scope,c_MHelp){
	$scope.titl=c_MHelp;
	// $scope.user_mid= document.forms["signinform"]["mid"].value;
	// $scope.user_password= document.forms["signinform"]["password"].value;
});
