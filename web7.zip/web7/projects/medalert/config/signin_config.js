angular.module("medalert").config(function($routeProvider){
	$routeProvider
	.when("/",{
		controller : "signin",
		templateUrl : "medalert/views/signin.html"
	});
});
