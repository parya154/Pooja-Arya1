(function(){
angular.module("mymode",[]);	
}());

