(function(){
	angular.module("mymode").controller("controller",myfun);
	
	function myfun(){
		this.name="bruce";
		this.city="gotham"
	}
}());
