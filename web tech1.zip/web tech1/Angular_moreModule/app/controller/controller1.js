angular.module("main")
	.controller("controller1",function($scope){
		$scope.message1="hello world";
	});