angular.module("child")
	.controller("controller2",function($scope){
		$scope.message2="welcome to possible";
	});