(function(){
	angular.module("mymod").controller("phancontroller",phanfun);
	
	function phanfun(){
		this.title="phantom";
		 this.fname="kit";
		this.lname="walker";
		this.city="bhangala"
		this.photo="images/phantom.jpg"

	}
}());