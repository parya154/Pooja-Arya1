(function(){
	angular.module("mymod").controller("spicontroller",spifun);
	
	function spifun(){
		this.title="Spiderman";
		 this.fname="peter";
		this.lname="parker";
		this.city="New York"
		this.photo="images/spiderman.jpg"
	}
}());