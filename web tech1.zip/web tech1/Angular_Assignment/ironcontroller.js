(function(){
	angular.module("mymod").controller("ironcontroller",ironfun);
	
	function ironfun(){
		this.title="Ironman";
		 this.fname="Tony";
		this.lname="stark";
		this.city="New York"
		this.photo="images/ironman.jpg"

	}
}());