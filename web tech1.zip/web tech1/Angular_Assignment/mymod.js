(function(){
angular.module("mymod",[]);	
}());

