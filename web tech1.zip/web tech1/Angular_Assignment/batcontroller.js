(function(){
	angular.module("mymod").controller("batcontroller",batfun);
	
	function batfun(){
		this.title="batman"
		this.fname="bruce";
		this.lname="lee";
		this.city="gotham"
		this.photo="images/batman.jpg"
	}
}());
