(function(){
	angular.module("mymod").controller("supercontroller",superfun);
	
	function superfun(){
		this.title="Superman";
		 this.fname="clark";
		this.lname="kent";
		this.city="metropolis"
		this.photo="images/superman.jpg"

	}
}());