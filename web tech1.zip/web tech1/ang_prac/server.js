ar express=require("express");
var bp=require("body-parser");
var mongo=require("mongojs");
var app=express();
var db=mongo("employee",['emp']);

app.get("/",function(req,res){
	db.emp.find(function(error,data){
		console.log(data);
	})
})

app.listen(1111)
console.log("port 1111")
