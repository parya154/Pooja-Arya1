angular.module("medhelp").controller("admin",function($rootScope,$scope,$http,$interval){
                $scope.lon=null;
                $scope.lat=null;
               $scope.pos=null;
               $scope.show=null;
               $scope.l=null;
               $scope.detailsshow=false;
               $scope.notificationshow=false;
                $scope.showLoc=function(){
                     console.log(" IN showLoc");
                     $http.get("/show_loc")
                     .success(function(r,s,x){
                           $scope.l=r.length-1;
                           console.log($scope.l);
                           $scope.pos=r;
                           $scope.i=0
                           for(i=0;i<r.length;i++){
                           	if(r[i].seen==true)
                           {
                            console.log($scope.pos);
                           console.log($scope.pos[i].longitude);
                           //console.log(r.lat + " "+ r.lon);
                           $scope.notificationshow=true;
                           $scope.lon=$scope.pos[i].longitude;
                           $scope.lat=$scope.pos[i].latitude;
                           $rootScope.mid=$scope.pos[i]._id;
                           $scope.nm=$scope.pos[i].name;
                           $scope.bg=$scope.pos[i].bloodgroup;
                           $scope.gender=$scope.pos[i].gender;
                           $scope.age=$scope.pos[i].age;
                           
                           console.log($scope.lon);
                           }
                           }
                           
                     });
                };//showLoc
                

                     function errorFun(){
                           console.log("Error");
                     }//errorFun
                     
                                $interval($scope.showLoc,5000);
                                $scope.detailsfun=function(){
                     $scope.detailsshow=!$scope.detailsshow;
                     
                };
                $scope.approvefun=function(){
                     console.log($rootScope.mid);
                   var  mid=$rootScope.mid;
                   
                    $http.put("/approve/"+mid)
        			.success(function(r,s,x){
        				$scope.notificationshow=false;
        				$scope.detailsshow=false;
        				console.log("Record updated");
        				
        			})
        			.error(function(e,s,x){
        				alert("Error");
        			});
                };        
           });
