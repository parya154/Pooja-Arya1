angular.module("medhelp").controller("signin", function($scope,$location,$rootScope){
		$rootScope.display=false;
	
      if ( localStorage.un3 == null || localStorage.un3=="undefined" ) {
         $location.path("/");
         //remove href =editdetails in signin
        } 
        
        else if(localStorage.un3 == "M1035897") {
          // not going to #login, we should redirect now
          $location.path("/adminpage");
          localstrorage.clear();
     //     alert("hello");
     //   redirectTo( "/fourthpage" );
      // $location= 'route/to/fourthpage';
        // $window.location.href = '/fourthpage';    
          
     
      }
      else if(localStorage.un3!="M1035897"){
      	 $location.path("/homepage");
      }
      else{
      	$location.path("/editdetails");
      }
     
	$scope.disp = function(){
		localStorage.un3=$scope.username;
	if ( localStorage.un3 == null || localStorage.un3=="undefined" ) {
         $location.path("/");
         //remove href =editdetails in signin
        } 
        
        else if(localStorage.un3 == "M1035897") {
          // not going to #login, we should redirect now
          $location.path("/adminpage");
     //     alert("hello");
     //   redirectTo( "/fourthpage" );
      // $location= 'route/to/fourthpage';
        // $window.location.href = '/fourthpage';    
          
     
      }
      else if(localStorage.un3!="M1035897"){
      	 $location.path("/editdetails");
      }
      else{
      	$location.path("/homepage");
      }
		};

});
