angular.module("medhelp").config(function($routeProvider){
	$routeProvider
	.when("/",{
		controller : "signin",
		templateUrl : "medhelp/views/signin.html"
	})
	.when("/editdetails", {
		controller : "editdetails",
		templateUrl : "medhelp/views/editdetails.html"
	})
	.when("/homepage",{
		controller : "homepage",
		templateUrl : "medhelp/views/homepage.html" 
	});
	});
