angular.module("medhelp").controller("homepage", function($scope){
	
})
