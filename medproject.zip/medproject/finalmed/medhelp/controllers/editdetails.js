angular.module("medhelp").controller("editdetails", function($scope){
	
})
