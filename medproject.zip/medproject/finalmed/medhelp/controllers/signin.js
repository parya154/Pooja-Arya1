angular.module("medhelp").controller("signin", function($scope,$location){
	
		
	if ( localStorage.un3 == null || localStorage.un3=="undefined" ) {
         $location.path("/");
        
          // already going to #login, no redirect needed
        } else {
          // not going to #login, we should redirect now
          $location.path("/homepage");
     //     alert("hello");
     //   redirectTo( "/fourthpage" );
      // $location= 'route/to/fourthpage';
        // $window.location.href = '/fourthpage';    
          
        }
	
	$scope.disp = function(){
	localStorage.un3 = $scope.username;
	};
});
