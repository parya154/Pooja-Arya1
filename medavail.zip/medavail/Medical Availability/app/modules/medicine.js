(function(){
 angular.module("medicine",["ngRoute"]);
}());
