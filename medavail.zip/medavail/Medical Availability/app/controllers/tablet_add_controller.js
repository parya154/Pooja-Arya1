(function(){
angular.module("medicine")
   .controller("tablet_add_controller",function($scope,$http){
    console.log("Controller loaded");
    $scope.tablist = null ;
    $scope.id=null;
    $scope.name=null;    
    $scope.dose=null;
    $scope.quantity=null;
    $scope.expiry_date=null;
    $scope.issued_on=null;
    $scope.symptoms=null;
    $scope.description=null;    
     
    $scope.add=function(){
     console.log("Checking . . ");
     //console.log($scope.id && $scope.name && $scope.quantity && $scope.dose && $scope.expiry_date && $scope.issued_on && $scope.symptoms && $scope.description);
     console.log($scope.name);
     console.log($scope.quantity);
     console.log($scope.dose);
     console.log($scope.expiry_date);
     console.log($scope.issued_on);
     console.log($scope.symptoms);
     console.log($scope.description);
     if($scope.id && $scope.name && $scope.quantity && $scope.dose && $scope.expiry_date && $scope.issued_on && $scope.symptoms && $scope.description)
     { 
      console.log("Values  .. . .");  
      var exp =new Date($scope.expiry_date.toString());
      var issued_on =new Date($scope.issued_on);
      var expr_formed =exp.getDate()+"/"+exp.getMonth()+"/"+exp.getFullYear();
      var issued_formed = issued_on.getDate()+"/"+issued_on.getMonth()+"/"+issued_on.getFullYear();
      console.log(expr_formed);
      console.log(issued_formed);  
      if($scope.expiry_date > $scope.issued_on)
      {
       console.log("Adding . . ");
       var data={
        "_id"        :$scope.id.toString(),
        "name"       :$scope.name,
        "quantity"   :$scope.quantity.toString(),
        "dose"       :$scope.dose,
        "expiry_date":expr_formed,
        "issued_on"  :issued_formed,
        "symptoms"   :$scope.symptoms,
        "description":$scope.description
       };
       $http.post("/list",data)
        .success(function(r,s,x){
         console.log("Updated");
         alert("Added To database");
        })
        .error(function(e,s,x){
         
        });
     }
     else
     {
      alert("Expiry date should be greater than issued on . ."); 
     }
     
    }    
   };
 });
 }());