(function(){
 angular.module("medicine").controller("logincontroller",function($scope,$http, $location,$rootScope){
   console.log("controller");
   $rootScope.id = null;
   $rootScope.name = null;
   $scope.validate = function(){
   
    var data = {
     mid : $scope.username,
     pwd : $scope.password
    };
    
    $http.post("/login",data)
    .success(function(r,s,x){
    	if(r)
    	{
		     if(r.accesslevel == 1){
		      $rootScope.id = r.mid;
		      $rootScope.name = r.name;
		      $location.path("/campusmind");
		     }
		     else if(r.accesslevel == 2){
		      $rootScope.id = r.mid;
		      $rootScope.name = r.name;
		      $location.path("/admin");
		     }
		      else if(r.accesslevel == 3){
		      $rootScope.id = r.mid;
		      $rootScope.name = r.name;
		      $location.path("/doctor");
		     }
		     else{
		     	if($scope.password!="" && $scope.username!="")
	    		{
			     	alert("invalid login credentials");
	    		}else{
	    			
	    		}
		     }
	    }
	    else{
	    		if($scope.password!="" && $scope.username!="")
	    		{
			     	alert("invalid login credentials");
	    		}
		     }
    })
    .error(function(e,s,x){
     console.log(e);
    });
   };
 });
}());