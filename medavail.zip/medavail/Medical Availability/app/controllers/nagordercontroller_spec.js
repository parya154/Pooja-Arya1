describe("This is my first test on angular",function(){
	
	beforeEach(
		module("app")      //
	);
	
	var controller = null;
	
	beforeEach(
		
		inject(function($controller){      //inject - load the controller
			controller = $controller;      //$controller has list of all controller
		})
	);
	
	it("checking for the title",function(){
		var emptyScope={};
		controller("nagaordercontroller",{
			$scope:emptyScope
			
		});
		expect(emptyScope.title()).toBe("batman");
	});
	
});

