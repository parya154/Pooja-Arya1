(function(){
 angular.module("medicine").controller("page1controller",function($scope,$http,$rootScope){
  
  $scope.doctorlog = null;
  $scope.date ="";
  $scope.tabid ="";
  $scope.mid ="";
  $scope.count="";
  $scope.symp="";
  $scope.status="";
  $scope.display=false;
  $scope.message="";
   
   $scope.id = $rootScope.id;
   $scope.name=$rootScope.name;
   function successHandler(r,s,x){
    $scope.doctorlog = r;
    if($scope.status===null){
     notify();
    }
   };
   function errorHandler(e,s,x){
    alert("Some thing went wrong");
   };
   function notify(){
    $scope.message =" CampusMind Is Requested for New tablets ";
   }
   $scope.fetch = function(){
    $http.get("/doclog")
    .success(successHandler)
    .error(errorHandler);
   };
 $scope.updateStatus = function(uid,tabname,count){
   $http.get("/checkquantity/"+tabname)     //medicine collection
   .success(function(r,s,x){
    console.log(r);
   if(r){ 
    if(r.quantity >= count){
     var quant = {
      quantity : r.quantity-count
     };
     var data = {
      status : "approved"  //doctorlog collection
     };
     
     $http.put("/changequnatity/"+tabname,quant)  // medicine collection
     .success(function(r,s,x){
      $http.put("/approve/"+uid,data) //alteady done doctorlog collection
      .success(function(r,s,x){
       $scope.fetch();
      alert("your Request is Approved");
      }).error(function(e,s,x){
       alert("something wentwrong");
      });
     })
     .error(function(e,s,x){
      alert("Sorry!! quantity is insufficient");
     });
     
    }else{
     alert("requested quantity not available");
    }
    
    }
    else{
    	alert("no record found for this tablet");
    }
   })
   .error(function(e,s,x){
    alert("something wentwrong");
   });

    
   };
   $scope.reject = function(uid){
    var data = {
     status : "Rejected"
    };
    $http.put("/approve/"+uid,data)
    .success(function(r,s,x){
     $scope.fetch();
    alert("Request Rejected");
    }).error(function(e,s,x){
     alert("something wentwrong");
    });
   };
 });
}());