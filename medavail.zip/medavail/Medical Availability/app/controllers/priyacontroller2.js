(function(){
	angular.module("medicine").controller("priyacontroller2",function($scope,$http,$rootScope){
			
		$scope.status1="null";		
		$scope.fetchMid = $rootScope.id;
	
	$scope.add=function(){
		if($scope.fetchMid &&
			$scope.symptoms1 &&
			$scope.count1){
			var data={
			date : new Date(),
			mid:$scope.fetchMid,
			symptoms:$scope.symptoms1,
			tablet:$scope.tablet1,
			count:$scope.count1,
			others:$scope.others1,
			status:"null"
			};
		console.log(data);
		
			$http.post("/doctorlist",data) // to post to server 
			.success(function(r,s,x){
				console.log(r);
				alert("request sent");
				//refresh();
			})
			.error(function(e,s,x){
				alert("error");
			});
			
	};
		
	};


	
	});
}());
