(function(){
	angular.module("medicine")
	.controller("priyacontroller3",function($scope,$http,$rootScope){
		//$scope.status="null";
		$scope.result="null";
		$scope.userid=$rootScope.id;
		console.log("controller3");
		console.log($scope.userid);
		var refresh=function(){
			/*
			$scope.mid="";
			$scope.symptoms="";
			$scope.tablet="";
			$scope.count="";
			$scope.others="";
			$scope.status="pending";
			 */
			$http.get("/doctorlist/"+$scope.userid)
			.success(function(r,s,x){
				$scope.result = r;
				/*
				$scope.mid=r.mid;
				$scope.symptoms=r.symptoms;
				$scope.tablet=r.tablet;
				$scope.count=r.count;
				$scope.others=r.others;
				$scope.status=r.status;
				 */
			})
			.error(function(e,s,x){
				alert("error 1");
			});
		};
			refresh();
	});
		}());