var hero=function(){
	

};

hero.prototype.age=function(){
	return 23;
};

hero.prototype.message=function(){
	return "heroes";
};

hero.prototype.comichero=function(){
	return true;
};

hero.prototype.visitedKalinga=function(){
	return false;
};

hero.prototype.walk=function(gen){
	return gen+10;
};

hero.prototype.fullname=function(gen){
	if(!fname || !lname){
		throw new Error("i need both params");
	}
	return fname+" "+lname;
};