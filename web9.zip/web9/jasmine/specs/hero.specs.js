describe("check hero's properties",function(){
	var Hero=new hero();
	it("the age returned must be more than 18",function(){
		expect(Hero.age()).toBeGreaterThan(18);
	})
	
	it("the messahes to be heroes",function(){
		expect(Hero.message()).toBe("heroes");
	})
	
	it("the value must be true",function(){
		expect(Hero.comichero(8)).toBeTruthy();
	})
	
	it("walk to be more than general walk speed",function(){
		expect(Hero.walk(8)).toBeLessThan(20);
	})
		it("batman never visited kalinga",function(){
		expect(Hero.visitedKalinga()).toBeFalsy();
	})
	it("must throw error if one of param is missing",function(){
		var result=function(){
			hero.fullname("bruce");
		}
		expect(result).toThrow();
	});
});

