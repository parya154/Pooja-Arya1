var fun1=function(){
	console.log("value from 1");
};
