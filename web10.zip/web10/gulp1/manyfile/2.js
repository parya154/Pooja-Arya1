var fun2=function(){
	console.log("value from 2");
};
