var fun3=function(){
	console.log("value from 3");
};
