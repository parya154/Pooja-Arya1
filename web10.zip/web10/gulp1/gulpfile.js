var gulp=require("gulp");
var gulputil=require("gulp-util");
var concat=require("gulp-concat");
var ugly=require("gulp-uglify");	
gulp.task("mindtree",function(){
	gulputil.log("first task");
});


var manyfile=['manyfile/1.js','manyfile/2.js','manyfile/3.js']
gulp.task("mindtree",function(){
	gulputil.log("first task");
});
gulp.task("concat",function(){   //this files needs more config like where are the files and destination
	gulp.src(manyfile).pipe(concat("main.js")).pipe(gulp.dest("script"));
})

gulp.task("mini",function(){
	gulp.src("script/main.js").pipe(ugly({mangle:false})).pipe(gulp.dest("dist"));   //mangle dnt change args
});

gulp.task("brow",function(){
	gulp.src("modules/app.js")
	.pipe(browserify({
		insertGlobals:false
	}))
	.pipe(gulp.dest("script"))
})


gulp.task("default",["concat","mini"],function(){
	gulputil.log("default called");
})
