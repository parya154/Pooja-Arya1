var fun1=function(){
	console.log("value from 1");
};

var fun2=function(){
	console.log("value from 2");
};

var fun3=function(){
	console.log("value from 3");
};
