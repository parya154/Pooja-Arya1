angular.module("app").controller("controller",function($scope){
	$scope.title=function(){
		return "batman";
	}
})
